import React, {Component} from 'react';
import {StyleSheet, View, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
const Tab = createBottomTabNavigator();
import {enableScreens} from 'react-native-screens';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Home from './screens/Home';
import Catogery from './screens/Catogery';
import Bags from './screens/Bags';
import Profile from './screens/Profile';
enableScreens();
export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({route}) => ({
          tabBarIcon: ({focused, color, size}) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home';
            } else if (route.name === 'Category') {
              iconName = focused ? 'apps' : 'apps';
            } else if (route.name === 'Bags') {
              iconName = focused ? 'shopping-cart' : 'shopping-cart';
            } else if (route.name === 'Profile') {
              iconName = focused ? 'person' : 'person';
            }
            return <Icon name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          activeTintColor: '#098b4d',
          inactiveTintColor: 'black',
        }}>
        <Tab.Screen name="Home" component={Home} />
        <Tab.Screen name="Category" component={Catogery} />
        <Tab.Screen name="Bags" component={Bags} />
        <Tab.Screen name="Profile" component={Profile} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
